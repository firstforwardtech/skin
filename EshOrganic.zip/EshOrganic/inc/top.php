<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Esh organics</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.ico">
    
    <!-- CSS 
    ========================= -->

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="assets/css/plugins.css">
    
    <!-- Main Style CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <!--header area start-->
    <header class="header_area">
        <!--header top area start-->
        
        <!--header top area end -->
        
        <!--header middle area start-->
        <div class="header_middle">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-12">
                        <div class="logo logo_three">
                            <a href="index.php"><img src="assets/img/logo/esh1.jpeg" alt=""></a>
                        </div>
                    </div>
                    <div class="col-lg-10 col-md-12">
                        <div class="header_middle_right">
                            <div class="header_contact">
                                <div class="contact_static">
                                    <a href="#"><i class="ion-android-call"></i> Call Us: +91-8427004555</a>
                                    <span>MON- SAT 8:30 AM - 6:00 PM</span>
                                </div>
                                <div class="contact_static">
                                    <a href="#"><i class="ion-android-mail"></i> eshorganics@gmail.com</a>
                                    <span>Esh Organics ONLINE SUPPORT 24H/7</span>
                                </div>
                            </div>
                            <div class="mini_cart_wrapper mini_cart_three">
                                <a href="javascript:void(0)"><i class="ion-bag"></i> $0.00 <span>2</span></a>
                                <!--mini cart-->
                                <div class="mini_cart">
                                    <div class="cart_item">
                                       <div class="cart_img">
                                           <a href="#"><img src="assets/img/s-product/product.jpg" alt=""></a>
                                       </div>
                                        <div class="cart_info">
                                            <a href="#">Condimentum Watches</a>

                                            <span class="quantity">Qty: 1</span>
                                            <span class="price_cart">$60.00</span>

                                        </div>
                                        <div class="cart_remove">
                                            <a href="#"><i class="ion-android-close"></i></a>
                                        </div>
                                    </div>
                                    <div class="cart_item">
                                       <div class="cart_img">
                                           <a href="#"><img src="assets/img/s-product/product2.jpg" alt=""></a>
                                       </div>
                                        <div class="cart_info">
                                            <a href="#">Officiis debitis</a>
                                            <span class="quantity">Qty: 1</span>
                                            <span class="price_cart">$69.00</span>
                                        </div>
                                        <div class="cart_remove">
                                            <a href="#"><i class="ion-android-close"></i></a>
                                        </div>
                                    </div>
                                    <div class="mini_cart_table">
                                        <div class="cart_total">
                                            <span>Subtotal:</span>
                                            <span class="price">$138.00</span>
                                        </div>
                                    </div>
                                    <div class="mini_cart_footer">
                                       <div class="cart_button">
                                            <a href="cart.php">View cart</a>
                                            <a href="checkout.php">Checkout</a>
                                        </div>
                                    </div>
                                </div>
                                <!--mini cart end-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--header middle area end-->
        
        <!--header bottom start-->
        <div class="header_bottom sticky-header">
            <div class="container">
                <div class="header_container_right container_position">
                    <div class="main_menu menu_three"> 
                        <nav>  
                            <ul>
                                <li class="active"><a  href="index.php"> home</a>
                                </li>
                                
                                <li><a href="blog.php"> Services</a>
                                    <ul class="sub_menu pages">
                                        <li><a href="blog-details.php">Consultancy</a></li>
                                        <li><a href="blog-fullwidth.php">Book Service Slot</a></li>
                                        <li><a href="blog-sidebar.php">google Calendar</a></li>
                                        <li><a href="blog-sidebar.php">Confirmation/Booked</a></li>
                                    </ul>
                                </li>
                                <li class="mega_items"><a href="shop.php"> Products</a> 
                                    <div class="mega_menu">
                                        <ul class="mega_menu_inner">
                                            <li><a href="#">Shop Layouts</a>
                                                <ul>
                                                    <li><a href="shop-fullwidth.php">Full Width</a></li>
                                                    <li><a href="shop-fullwidth-list.php">Full Width list</a></li>
                                                    <li><a href="shop-right-sidebar.php">Right Sidebar </a></li>
                                                    <li><a href="shop-right-sidebar-list.php"> Right Sidebar list</a></li>
                                                    <li><a href="shop-list.php">List View</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">other Pages</a>
                                                <ul>
                                                    <li><a href="cart.php">cart</a></li>
                                                    <li><a href="wishlist.php">Wishlist</a></li>
                                                    <li><a href="checkout.php">Checkout</a></li>
                                                    <li><a href="my-account.php">my account</a></li>
                                                    <li><a href="404.php">Error 404</a></li>
                                                </ul>
                                            </li>
                                            <li><a href="#">Product Types</a>
                                                <ul>
                                                    <li><a href="product-details.php">product details</a></li>
                                                    <li><a href="product-sidebar.php">product sidebar</a></li>
                                                    <li><a href="product-grouped.php">product grouped</a></li>
                                                    <li><a href="variable-product.php">product variable</a></li>

                                                </ul>
                                            </li>
                                            <li><img src="assets/img/bg/img-itemmenu.jpg" alt=""></li>
                                        </ul>
                                    </div>
                                </li>
                                <li><a href="#"> pages</a>
                                    <ul class="sub_menu pages">
                                        <li><a href="about.php">About Us</a></li>
                                        <li><a href="services.php">services</a></li>
                                        <li><a href="faq.php">Frequently Questions</a></li>
                                        <li><a href="contact.php">contact</a></li>
                                        <li><a href="login.php">login</a></li>
                                        <li><a href="wishlist.php">Wishlist</a></li>
                                        <li><a href="404.php">Error 404</a></li>
                                    </ul>
                                </li>
                                <li><a href="contact.php">  Contact Us</a></li>
                            </ul>  
                        </nav> 
                    </div>
                    <div class="header_block_right">
                        <ul>
                            <li class="search_bar"><a href="javascript:void(0)"><i class="ion-ios-search-strong"></i></a> </li>
                        </ul>
                    </div>
                </div>
            </div>
            <!--header bottom end-->
        </div>
    </header>
    <!--header area end-->
    <!--search overlay-->
    
    <div class="dropdown_search dropdown_search_three">
        <div class="search_close_btn">
            <i class="ion-android-close btn-close"></i>
        </div>
        <div class="search_container">
            <form action="#">
                <input placeholder="I’m shopping for..." type="text">
                <button type="submit"><i class="ion-ios-search-strong"></i></button>
            </form>
        </div>
    </div>
    
    <!--search overlay end-->

    <!--Offcanvas menu area start-->
    
    <div class="off_canvars_overlay">
                
    </div>
