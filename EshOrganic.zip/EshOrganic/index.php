    <?php include('inc/top.php'); ?>
    <!--Offcanvas menu area end-->
    
    <!--slider area start-->
    <section class="slider_section slider_section_three">
       <div class="slider_area owl-carousel">
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/6.png">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content slider_c_three">
                                <h1 style="color: red;">Neem Wood</h1>
                                <p>We’ve been squeezing oranges in Alista for over 20 years, and we are proud.</p>
                                <a href="#">shop now</a>
                            </div>
                        </div>
                    </div>
                </div> 
                
            </div>
            <div class="single_slider d-flex align-items-center" data-bgimg="assets/img/slider/7.jpg">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="slider_content slider_c_three color_three">
                                <h1 style="color: red;">Organic Comb</h1>
                                <p>Learn more about our product philosophy, and the benefits of microbiome-friendly skincare.</p>
                                <a href="#">shop now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--slider area end-->
    
    <!--brand newsletter area start-->
    
    <!--brand area end-->
    
     <!--banner area start-->
    <div class="banner_area banner_three pt-70 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3>Featured category</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/1.jpg" alt=""></a>
                            <div class="banner_text">
                                <a href="#">Aliquam Malesuada</a>
                            </div>
                        </div>
                       
                    </div>
                </div> 
                <div class="col-lg-3 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/2.jpg" alt=""></a>
                            <div class="banner_text">
                                <a href="#">Etiam eleifend</a>
                            </div>
                        </div>
                       
                    </div>
                </div> 
                <div class="col-lg-3 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/3.jpg" alt=""></a>
                            <div class="banner_text">
                                <a href="#">Integer Felis</a>
                            </div>
                        </div>
                       
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/4.jpg" alt=""></a>
                            <div class="banner_text">
                                <a href="#">Semper Vulputate</a>
                            </div>
                        </div>
                    </div>
                </div>       
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--new product area start-->
    <section class="product_area product_three mb-40">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3> Our Products</h3>
                    </div>
                </div>
            </div>
            <div class="product_wrapper product_color3">
                <div class="row product_slick_column4">
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Pendant, Made of White Pl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Swirl 1 Medium Pendant La...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Vitra Sunburst Clock pret...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Light Inverted Pendant Qu...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Poly and Bark Eames Style...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>  

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Le Klint Carronade Pendel...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">JWDA Penant Lamp Brshed S...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Suspensions Aplomb Large ...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--new product area end-->
    
    <!--banner fullwidth area start-->
    <div class="banner_fullwidth">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-12">
                    <div class="banner_thumb">
                        <a href="shop.php"><img src="assets/img/bg/banner21.jpg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--banner fullwidth area end-->
    
    <!--new product area start-->
    <section class="product_area product_three mb-40">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_title title_style3">
                        <h3> Best Sellers</h3>
                    </div>
                </div>
            </div>
            <div class="product_wrapper product_color3">
                <div class="row product_slick_column4">
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Pendant, Made of White Pl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Swirl 1 Medium Pendant La...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Vitra Sunburst Clock pret...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Light Inverted Pendant Qu...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Poly and Bark Eames Style...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>  

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Le Klint Carronade Pendel...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">JWDA Penant Lamp Brshed S...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div> 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Suspensions Aplomb Large ...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/4.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/6.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/3.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/5.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/1.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/8.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="product-details.php"><img src="assets/img/product/2.jpg" alt=""></a>
                                <a class="secondary_img" href="product-details.php"><img src="assets/img/product/7.jpg" alt=""></a>
                                <div class="label_product">
                                    <span class="label_sale">new</span>
                                </div>
                                <div class="action_links">
                                    <ul>
                                        <li class="add_to_cart"><a href="cart.php" title="add to cart"><i class="ion-bag"></i></a></li>
                                        <li class="compare"><a href="#" title="Add to Compare"><i class="ion-ios-shuffle-strong"></i></a></li>
                                        <li class="quick_view"><a href="#" data-toggle="modal" data-target="#modal_box" title="Quick View"><i class="ion-eye"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product_content">
                                <div class="product_name">
                                    <h4><a href="product-details.php">Ipoly and Bark Eames Styl...</a></h4>
                                </div>
                                <div class="product_rating">
                                    <ul>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                        <li><a href="#"><i class="zmdi zmdi-star-outline"></i></a></li>
                                    </ul>
                                </div>
                                <div class="price-container">
                                     <div class="price_box">
                                        <span class="current_price">$65.00</span>
                                        <span class="old_price">$70.00</span>   
                                    </div>
                                    <div class="wishlist_btn">
                                        <a href="wishlist.php" title="wishlist"><i class="ion-android-favorite-outline"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--new product area end-->

    <!--banner area start-->
    <div class="banner_area banner_three_column2">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner23.jpg" alt=""></a>
                        </div>
                    </div>
                </div>  
                <div class="col-lg-6 col-md-6">
                    <div class="single_banner">
                        <div class="banner_thumb">
                            <a href="shop.php"><img src="assets/img/bg/banner24.jpg" alt=""></a>
                        </div>
                    </div>
                </div>      
            </div>
        </div>
    </div>
    <!--banner area end-->

    <!--footer area start-->
  <?php include('inc/footer.php'); ?>